--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: file; Type: TABLE; Schema: public; Owner: seasky-developer
--

CREATE TABLE public.file (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(64),
    size integer,
    path character varying(255),
    CONSTRAINT ch_file_size CHECK (((size > 0) AND (size <= 26214400)))
);


ALTER TABLE public.file OWNER TO "seasky-developer";

--
-- Name: role; Type: TABLE; Schema: public; Owner: seasky-developer
--

CREATE TABLE public.role (
    id smallint NOT NULL,
    power bigint DEFAULT 0 NOT NULL,
    meaning character varying(128) NOT NULL
);


ALTER TABLE public.role OWNER TO "seasky-developer";

--
-- Name: role_id_seq; Type: SEQUENCE; Schema: public; Owner: seasky-developer
--

CREATE SEQUENCE public.role_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_id_seq OWNER TO "seasky-developer";

--
-- Name: role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seasky-developer
--

ALTER SEQUENCE public.role_id_seq OWNED BY public.role.id;


--
-- Name: status; Type: TABLE; Schema: public; Owner: seasky-developer
--

CREATE TABLE public.status (
    id smallint NOT NULL,
    name character varying(128) NOT NULL
);


ALTER TABLE public.status OWNER TO "seasky-developer";

--
-- Name: status_id_seq; Type: SEQUENCE; Schema: public; Owner: seasky-developer
--

CREATE SEQUENCE public.status_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.status_id_seq OWNER TO "seasky-developer";

--
-- Name: status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seasky-developer
--

ALTER SEQUENCE public.status_id_seq OWNED BY public.status.id;


--
-- Name: task; Type: TABLE; Schema: public; Owner: seasky-developer
--

CREATE TABLE public.task (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    markdown text,
    due_date timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    creator_id uuid NOT NULL,
    status_id smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.task OWNER TO "seasky-developer";

--
-- Name: task_file; Type: TABLE; Schema: public; Owner: seasky-developer
--

CREATE TABLE public.task_file (
    task_id uuid NOT NULL,
    file_id uuid NOT NULL
);


ALTER TABLE public.task_file OWNER TO "seasky-developer";

--
-- Name: task_instance; Type: TABLE; Schema: public; Owner: seasky-developer
--

CREATE TABLE public.task_instance (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    task_id uuid NOT NULL,
    executor_id uuid NOT NULL,
    status_id smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.task_instance OWNER TO "seasky-developer";

--
-- Name: user; Type: TABLE; Schema: public; Owner: seasky-developer
--

CREATE TABLE public."user" (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    username character varying(32) NOT NULL,
    password text NOT NULL,
    name character varying(255),
    email character varying(255),
    is_active boolean DEFAULT false NOT NULL,
    role_id smallint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ch_user_username CHECK ((length((username)::text) >= 4))
);


ALTER TABLE public."user" OWNER TO "seasky-developer";

--
-- Name: role id; Type: DEFAULT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.role ALTER COLUMN id SET DEFAULT nextval('public.role_id_seq'::regclass);


--
-- Name: status id; Type: DEFAULT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.status ALTER COLUMN id SET DEFAULT nextval('public.status_id_seq'::regclass);


--
-- Data for Name: file; Type: TABLE DATA; Schema: public; Owner: seasky-developer
--

COPY public.file (id, name, size, path) FROM stdin;
5d4263f3-dd31-4fb5-b262-dc8b350063f6	0ma3cZgyj2Q.jpg	194547	C:\\Docs\\Kotlin\\tms\\_files\\6890c33b-daa6-4e61-aec2-369d908957cc\\fhc1695071940bhc194547.jpg
b6c7edf0-a4ea-43d6-a21c-6c031680b1f3	photo_2021-02-21_19-15-44.jpg	10897	C:\\Docs\\Kotlin\\tms\\_files\\6890c33b-daa6-4e61-aec2-369d908957cc\\fhc-1050509873bhc10897.jpg
0b499b02-54ca-439c-8fba-256906ca11c9	photo_2021-02-21_19-15-44.jpg	10897	C:\\Docs\\Kotlin\\tms\\_files\\176326c7-686a-40a6-b7d2-08dad1a10678\\fhc-1050509873bhc10897.jpg
\.


--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: seasky-developer
--

COPY public.role (id, power, meaning) FROM stdin;
1	0	Неизвестный чел
5	0	Моя роль
6	0	Твоя роль
7	0	Ваша роль
8	0	Наша роль
9	0	Маша роль
10	0	Каша роль
2	1	Администратор
\.


--
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: seasky-developer
--

COPY public.status (id, name) FROM stdin;
1	Новые
2	В работе
3	Отмененные
4	Завершенные
5	Подготовленные
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: seasky-developer
--

COPY public.task (id, title, description, markdown, due_date, created_at, creator_id, status_id) FROM stdin;
6890c33b-daa6-4e61-aec2-369d908957cc	Таша	\N	Markdown	2021-03-12 17:52:09+00	2021-03-30 18:28:58.657994+00	697409b4-99ef-4f64-84ee-f0329bb20fab	1
e1176ff9-a1f0-489b-9a12-ab9480661712	Таша	\N	Markdown	2021-03-12 14:52:09+00	2021-03-30 20:08:00.496566+00	697409b4-99ef-4f64-84ee-f0329bb20fab	1
a254a112-9a50-4efc-8ca3-8581bc6fb6aa	Таша	\N	Markdown	2021-03-11 21:52:09+00	2021-03-30 21:23:37.508972+00	697409b4-99ef-4f64-84ee-f0329bb20fab	1
69505c86-b1c2-4fc1-94d2-b65162122f3c	Таша	\N	asd\ngg	2021-03-11 21:52:09+00	2021-03-30 21:31:55.787804+00	697409b4-99ef-4f64-84ee-f0329bb20fab	1
f8e68763-0fda-48ec-8f71-e3b858291a28	super-name	super-description	\N	2021-03-31 17:37:00+00	2021-03-31 17:37:48.375978+00	697409b4-99ef-4f64-84ee-f0329bb20fab	1
176326c7-686a-40a6-b7d2-08dad1a10678	asdasd	desc	\N	2021-04-30 04:06:00+00	2021-04-01 04:08:59.651173+00	77a2e012-d3cf-4bf9-9773-47a019019658	1
1c7b514d-a593-4656-9650-5ccbe8cf576e	1234		\N	2021-04-02 04:10:00+00	2021-04-01 04:10:33.31471+00	77a2e012-d3cf-4bf9-9773-47a019019658	1
34f154b9-8e7f-402c-9873-a6f5384ba765	Задача №2222	\N	ПукПердук	2021-04-01 13:32:11.132456+00	2021-04-01 13:32:11.132456+00	697409b4-99ef-4f64-84ee-f0329bb20fab	2
\.


--
-- Data for Name: task_file; Type: TABLE DATA; Schema: public; Owner: seasky-developer
--

COPY public.task_file (task_id, file_id) FROM stdin;
6890c33b-daa6-4e61-aec2-369d908957cc	5d4263f3-dd31-4fb5-b262-dc8b350063f6
6890c33b-daa6-4e61-aec2-369d908957cc	b6c7edf0-a4ea-43d6-a21c-6c031680b1f3
176326c7-686a-40a6-b7d2-08dad1a10678	0b499b02-54ca-439c-8fba-256906ca11c9
\.


--
-- Data for Name: task_instance; Type: TABLE DATA; Schema: public; Owner: seasky-developer
--

COPY public.task_instance (id, task_id, executor_id, status_id) FROM stdin;
8f1dafed-eaa2-4466-aa2f-e5f52e45b7f4	6890c33b-daa6-4e61-aec2-369d908957cc	ad8322a7-0d3d-4331-afe4-a1712f73a524	1
db108265-33f8-4bb3-ad99-0c43bc37dfbc	6890c33b-daa6-4e61-aec2-369d908957cc	ce4ec35a-6e0f-42b2-94bf-618f4f8498fc	1
92e0045a-25d9-4fc0-a3d4-46588c21f83c	6890c33b-daa6-4e61-aec2-369d908957cc	ccf83b8a-8897-48ec-ab26-aae1551a282a	1
e3eb7e26-b94c-43c2-9c03-9aab77653ce5	6890c33b-daa6-4e61-aec2-369d908957cc	ce4ec35a-6e0f-42b2-94bf-618f4f8498fc	1
7d7d9474-402c-41e2-8e20-67dba8379cca	6890c33b-daa6-4e61-aec2-369d908957cc	ad8322a7-0d3d-4331-afe4-a1712f73a524	1
89c39181-81fe-4733-b053-fb07f02303c8	e1176ff9-a1f0-489b-9a12-ab9480661712	ad8322a7-0d3d-4331-afe4-a1712f73a524	1
a8fba034-94b1-49b6-b7e1-a0613e25a07f	e1176ff9-a1f0-489b-9a12-ab9480661712	ce4ec35a-6e0f-42b2-94bf-618f4f8498fc	1
ab5fe2c6-6c32-4f91-84bd-7afbebf8f490	e1176ff9-a1f0-489b-9a12-ab9480661712	ccf83b8a-8897-48ec-ab26-aae1551a282a	1
639a30ec-71d0-423d-8c23-20f6438ca115	a254a112-9a50-4efc-8ca3-8581bc6fb6aa	ad8322a7-0d3d-4331-afe4-a1712f73a524	1
3e5e6765-9410-4f89-8aaa-6a351e1b02d1	a254a112-9a50-4efc-8ca3-8581bc6fb6aa	ce4ec35a-6e0f-42b2-94bf-618f4f8498fc	1
6f99dd25-3502-4155-95f2-b38bfcb6f53d	a254a112-9a50-4efc-8ca3-8581bc6fb6aa	ccf83b8a-8897-48ec-ab26-aae1551a282a	1
7a4b9b18-f18c-4449-9551-3a98d7cf4040	69505c86-b1c2-4fc1-94d2-b65162122f3c	ad8322a7-0d3d-4331-afe4-a1712f73a524	1
5b394e22-40b9-44bf-a026-61856a92d928	69505c86-b1c2-4fc1-94d2-b65162122f3c	ce4ec35a-6e0f-42b2-94bf-618f4f8498fc	1
0205cbf4-2389-434c-93e3-b1b0034a0513	69505c86-b1c2-4fc1-94d2-b65162122f3c	ccf83b8a-8897-48ec-ab26-aae1551a282a	1
babc6cd8-6014-4a13-b4fb-67e1231739b6	f8e68763-0fda-48ec-8f71-e3b858291a28	ccf83b8a-8897-48ec-ab26-aae1551a282a	1
79310885-24f6-43a5-9b34-21927829c9de	176326c7-686a-40a6-b7d2-08dad1a10678	ce4ec35a-6e0f-42b2-94bf-618f4f8498fc	1
0c9353f8-d8bd-44f6-817c-1415707c5b45	1c7b514d-a593-4656-9650-5ccbe8cf576e	ce4ec35a-6e0f-42b2-94bf-618f4f8498fc	1
4b4efd26-8045-485e-a0e0-90465b7af025	176326c7-686a-40a6-b7d2-08dad1a10678	697409b4-99ef-4f64-84ee-f0329bb20fab	2
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: seasky-developer
--

COPY public."user" (id, username, password, name, email, is_active, role_id, created_at) FROM stdin;
ad8322a7-0d3d-4331-afe4-a1712f73a524	qqqq	$2a$06$xVbJC1ClUk52b9SIMtv1SOT2r2ayMz.1OvZ5tmuuxnR799VH3ikLW	\N	\N	t	2	2021-03-27 13:21:57.670632+00
ce4ec35a-6e0f-42b2-94bf-618f4f8498fc	beaver	$2a$06$HpeO36cluLvA5flk9NDGeeKzJPsdJm4N44tJTJPKbsmAnMQNwQAT2	Бобер Боберыч	beaver@mail.ru	t	1	2021-03-28 17:17:12.480017+00
2e49b88c-31e2-4414-bc9b-71fda5017c93	test	$2a$06$hZtTOEkYA6Fe/vN.CjEIsOpcCT2mYYc4SLVMEXNgAu1srp4WVmtbC	test-name	\N	t	1	2021-03-31 17:40:28.962365+00
77a2e012-d3cf-4bf9-9773-47a019019658	Muslim	$2a$06$by0BU2H8clf73Ix9JKFHSu55EYQ1NwAKzpyW8Pch2oeYTWg0P72f2	\N	muslim@gmail.com	t	2	2021-04-01 04:04:57.395717+00
697409b4-99ef-4f64-84ee-f0329bb20fab	admin	$2a$06$3SOvZUJxs4A.XKO77SmfdeX8RN0rFGZSht8hSuaqNvyrsNTcjaDc.	\N	admin@gmail.com	t	2	2021-03-27 12:40:30.314822+00
ccf83b8a-8897-48ec-ab26-aae1551a282a	aaaa	$2a$06$o/yLt2DInRIGejZ8kNVYXO2QTd4LXGQQWqRcbKVD8cCTVfSSRy4tW	\N	\N	f	2	2021-03-27 13:21:57.670632+00
\.


--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seasky-developer
--

SELECT pg_catalog.setval('public.role_id_seq', 10, true);


--
-- Name: status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seasky-developer
--

SELECT pg_catalog.setval('public.status_id_seq', 5, true);


--
-- Name: file pk_file_id; Type: CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT pk_file_id PRIMARY KEY (id);


--
-- Name: role pk_role_id; Type: CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT pk_role_id PRIMARY KEY (id);


--
-- Name: status pk_status_id; Type: CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT pk_status_id PRIMARY KEY (id);


--
-- Name: task_file pk_task_file_task_id_file_id; Type: CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.task_file
    ADD CONSTRAINT pk_task_file_task_id_file_id PRIMARY KEY (task_id, file_id);


--
-- Name: task pk_task_id; Type: CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT pk_task_id PRIMARY KEY (id);


--
-- Name: task_instance pk_task_instance_id; Type: CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.task_instance
    ADD CONSTRAINT pk_task_instance_id PRIMARY KEY (id);


--
-- Name: user pk_user_id; Type: CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT pk_user_id PRIMARY KEY (id);


--
-- Name: file uq_file_name_size_path; Type: CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT uq_file_name_size_path UNIQUE (name, size, path);


--
-- Name: user uq_user_username; Type: CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT uq_user_username UNIQUE (username);


--
-- Name: task fk_task_creator_id_id; Type: FK CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT fk_task_creator_id_id FOREIGN KEY (creator_id) REFERENCES public."user"(id);


--
-- Name: task_file fk_task_file_file_id_id; Type: FK CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.task_file
    ADD CONSTRAINT fk_task_file_file_id_id FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: task_file fk_task_file_task_id_id; Type: FK CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.task_file
    ADD CONSTRAINT fk_task_file_task_id_id FOREIGN KEY (task_id) REFERENCES public.task(id);


--
-- Name: task_instance fk_task_instance_executor_id_id; Type: FK CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.task_instance
    ADD CONSTRAINT fk_task_instance_executor_id_id FOREIGN KEY (executor_id) REFERENCES public."user"(id);


--
-- Name: task_instance fk_task_instance_status_id_id; Type: FK CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.task_instance
    ADD CONSTRAINT fk_task_instance_status_id_id FOREIGN KEY (status_id) REFERENCES public.status(id);


--
-- Name: task_instance fk_task_instance_task_id_id; Type: FK CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.task_instance
    ADD CONSTRAINT fk_task_instance_task_id_id FOREIGN KEY (task_id) REFERENCES public.task(id) ON DELETE CASCADE;


--
-- Name: task fk_task_status_id_id; Type: FK CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT fk_task_status_id_id FOREIGN KEY (status_id) REFERENCES public.status(id);


--
-- Name: user fk_user_role_id_id; Type: FK CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT fk_user_role_id_id FOREIGN KEY (role_id) REFERENCES public.role(id);


--
-- PostgreSQL database dump complete
--

