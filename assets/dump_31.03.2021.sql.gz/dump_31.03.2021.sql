--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: detail; Type: TABLE; Schema: public; Owner: seasky-developer
--

CREATE TABLE public.detail (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    task_id uuid NOT NULL,
    executor_id uuid NOT NULL,
    status_id smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.detail OWNER TO "seasky-developer";

--
-- Name: role; Type: TABLE; Schema: public; Owner: seasky-developer
--

CREATE TABLE public.role (
    id smallint NOT NULL,
    power bigint DEFAULT 0 NOT NULL,
    meaning character varying(128) NOT NULL
);


ALTER TABLE public.role OWNER TO "seasky-developer";

--
-- Name: role_id_seq; Type: SEQUENCE; Schema: public; Owner: seasky-developer
--

CREATE SEQUENCE public.role_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_id_seq OWNER TO "seasky-developer";

--
-- Name: role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seasky-developer
--

ALTER SEQUENCE public.role_id_seq OWNED BY public.role.id;


--
-- Name: status; Type: TABLE; Schema: public; Owner: seasky-developer
--

CREATE TABLE public.status (
    id smallint NOT NULL,
    name character varying(128) NOT NULL
);


ALTER TABLE public.status OWNER TO "seasky-developer";

--
-- Name: status_id_seq; Type: SEQUENCE; Schema: public; Owner: seasky-developer
--

CREATE SEQUENCE public.status_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.status_id_seq OWNER TO "seasky-developer";

--
-- Name: status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seasky-developer
--

ALTER SEQUENCE public.status_id_seq OWNED BY public.status.id;


--
-- Name: task; Type: TABLE; Schema: public; Owner: seasky-developer
--

CREATE TABLE public.task (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    markdown text,
    due_date timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    creator_id uuid NOT NULL,
    status_id smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.task OWNER TO "seasky-developer";

--
-- Name: user; Type: TABLE; Schema: public; Owner: seasky-developer
--

CREATE TABLE public."user" (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    username character varying(32) NOT NULL,
    password text NOT NULL,
    name character varying(255),
    email character varying(255),
    is_active boolean DEFAULT false NOT NULL,
    role_id smallint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ch_user_username CHECK ((length((username)::text) >= 4))
);


ALTER TABLE public."user" OWNER TO "seasky-developer";

--
-- Name: role id; Type: DEFAULT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.role ALTER COLUMN id SET DEFAULT nextval('public.role_id_seq'::regclass);


--
-- Name: status id; Type: DEFAULT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.status ALTER COLUMN id SET DEFAULT nextval('public.status_id_seq'::regclass);


--
-- Data for Name: detail; Type: TABLE DATA; Schema: public; Owner: seasky-developer
--

COPY public.detail (id, task_id, executor_id, status_id) FROM stdin;
8996139a-c707-4f1c-938b-f333eff61451	c87b860f-408c-470f-b4a5-dcd762ad27a9	ad8322a7-0d3d-4331-afe4-a1712f73a524	3
99775735-f5c4-44a3-86c2-528bd0dff5bf	c87b860f-408c-470f-b4a5-dcd762ad27a9	ccf83b8a-8897-48ec-ab26-aae1551a282a	1
096878af-5c8e-413b-9d18-23c269663ee5	c87b860f-408c-470f-b4a5-dcd762ad27a9	697409b4-99ef-4f64-84ee-f0329bb20fab	3
2ac2ac81-cbf7-4e1f-bacd-3711c7179d08	c87b860f-408c-470f-b4a5-dcd762ad27a9	697409b4-99ef-4f64-84ee-f0329bb20fab	1
919506ee-aacd-4416-835d-9d822c4631e5	c87b860f-408c-470f-b4a5-dcd762ad27a9	697409b4-99ef-4f64-84ee-f0329bb20fab	1
3421594d-522d-4fee-bbb1-f3dbe614469f	c87b860f-408c-470f-b4a5-dcd762ad27a9	697409b4-99ef-4f64-84ee-f0329bb20fab	1
89a06719-f0b9-4a61-b1bd-031443171a7f	c87b860f-408c-470f-b4a5-dcd762ad27a9	697409b4-99ef-4f64-84ee-f0329bb20fab	1
7fd534bc-9a9b-420c-81d4-448a620f6717	c87b860f-408c-470f-b4a5-dcd762ad27a9	697409b4-99ef-4f64-84ee-f0329bb20fab	1
78bb34d0-64b1-44dc-9d88-91f99ec750c5	c87b860f-408c-470f-b4a5-dcd762ad27a9	697409b4-99ef-4f64-84ee-f0329bb20fab	1
5f50ed3c-90fd-4ac3-8355-a080efe8eaa6	c87b860f-408c-470f-b4a5-dcd762ad27a9	697409b4-99ef-4f64-84ee-f0329bb20fab	1
f0d61f16-b050-444a-a165-eecd41190821	81aa9f99-04d5-4835-ba2d-5f0c7be766c8	697409b4-99ef-4f64-84ee-f0329bb20fab	1
85e56cc4-068c-413b-a1ae-accad4888e4a	81aa9f99-04d5-4835-ba2d-5f0c7be766c8	697409b4-99ef-4f64-84ee-f0329bb20fab	1
8f1dafed-eaa2-4466-aa2f-e5f52e45b7f4	6890c33b-daa6-4e61-aec2-369d908957cc	ad8322a7-0d3d-4331-afe4-a1712f73a524	1
db108265-33f8-4bb3-ad99-0c43bc37dfbc	6890c33b-daa6-4e61-aec2-369d908957cc	ce4ec35a-6e0f-42b2-94bf-618f4f8498fc	1
92e0045a-25d9-4fc0-a3d4-46588c21f83c	6890c33b-daa6-4e61-aec2-369d908957cc	ccf83b8a-8897-48ec-ab26-aae1551a282a	1
e3eb7e26-b94c-43c2-9c03-9aab77653ce5	6890c33b-daa6-4e61-aec2-369d908957cc	ce4ec35a-6e0f-42b2-94bf-618f4f8498fc	1
7d7d9474-402c-41e2-8e20-67dba8379cca	6890c33b-daa6-4e61-aec2-369d908957cc	ad8322a7-0d3d-4331-afe4-a1712f73a524	1
89c39181-81fe-4733-b053-fb07f02303c8	e1176ff9-a1f0-489b-9a12-ab9480661712	ad8322a7-0d3d-4331-afe4-a1712f73a524	1
a8fba034-94b1-49b6-b7e1-a0613e25a07f	e1176ff9-a1f0-489b-9a12-ab9480661712	ce4ec35a-6e0f-42b2-94bf-618f4f8498fc	1
ab5fe2c6-6c32-4f91-84bd-7afbebf8f490	e1176ff9-a1f0-489b-9a12-ab9480661712	ccf83b8a-8897-48ec-ab26-aae1551a282a	1
639a30ec-71d0-423d-8c23-20f6438ca115	a254a112-9a50-4efc-8ca3-8581bc6fb6aa	ad8322a7-0d3d-4331-afe4-a1712f73a524	1
3e5e6765-9410-4f89-8aaa-6a351e1b02d1	a254a112-9a50-4efc-8ca3-8581bc6fb6aa	ce4ec35a-6e0f-42b2-94bf-618f4f8498fc	1
6f99dd25-3502-4155-95f2-b38bfcb6f53d	a254a112-9a50-4efc-8ca3-8581bc6fb6aa	ccf83b8a-8897-48ec-ab26-aae1551a282a	1
7a4b9b18-f18c-4449-9551-3a98d7cf4040	69505c86-b1c2-4fc1-94d2-b65162122f3c	ad8322a7-0d3d-4331-afe4-a1712f73a524	1
5b394e22-40b9-44bf-a026-61856a92d928	69505c86-b1c2-4fc1-94d2-b65162122f3c	ce4ec35a-6e0f-42b2-94bf-618f4f8498fc	1
0205cbf4-2389-434c-93e3-b1b0034a0513	69505c86-b1c2-4fc1-94d2-b65162122f3c	ccf83b8a-8897-48ec-ab26-aae1551a282a	1
\.


--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: seasky-developer
--

COPY public.role (id, power, meaning) FROM stdin;
1	0	Неизвестный чел
2	127	Администратор
5	0	Моя роль
6	0	Твоя роль
7	0	Ваша роль
8	0	Наша роль
9	0	Маша роль
10	0	Каша роль
\.


--
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: seasky-developer
--

COPY public.status (id, name) FROM stdin;
1	Новые
2	В работе
3	Отмененные
4	Завершенные
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: seasky-developer
--

COPY public.task (id, title, description, markdown, due_date, created_at, creator_id, status_id) FROM stdin;
c87b860f-408c-470f-b4a5-dcd762ad27a9	Задача 1	\N	4. For UUID tables use extension `uuid-ossp`, for default value use a fourth version of uuid generator.\r\n\r\n   Ex.\r\n\r\n   ```\r\n   create extension if not exists "uuid-ossp";\r\n   create table user(\r\n      id uuid default uuid_generate_v4(),\r\n      ...\r\n   )\r\n   ```\r\n5. For a password storing use `pgcrypto` extension.\r\n\r\n   Ex.\r\n   ```\r\n   create table "user"(\r\n       id uuid default uuid_generate_v4(),\r\n       username varchar(36) not null,\r\n       "password" text not null\r\n   )\r\n   \r\n   insert into "user"(username, password)\r\n   values(username, crypt(pass, gen_salt(bf)))\r\n   \r\n   select password, (password = crypt(pass, password)) as password_match \r\n   from "user"\r\n   ```	2021-03-27 13:14:36.709578+00	2021-03-27 13:14:36.709578+00	697409b4-99ef-4f64-84ee-f0329bb20fab	1
81aa9f99-04d5-4835-ba2d-5f0c7be766c8	Задача 2	\N	4. For UUID tables use extension `uuid-ossp`, for default value use a fourth version of uuid generator.\r\n\r\n   Ex.\r\n\r\n   ```\r\n   create extension if not exists "uuid-ossp";\r\n   create table user(\r\n      id uuid default uuid_generate_v4(),\r\n      ...\r\n   )\r\n   ```\r\n5. For a password storing use `pgcrypto` extension.\r\n\r\n   Ex.\r\n   ```\r\n   create table "user"(\r\n       id uuid default uuid_generate_v4(),\r\n       username varchar(36) not null,\r\n       "password" text not null\r\n   )\r\n   \r\n   insert into "user"(username, password)\r\n   values(username, crypt(pass, gen_salt(bf)))\r\n   \r\n   select password, (password = crypt(pass, password)) as password_match \r\n   from "user"\r\n   ```	2021-03-29 18:23:59.452169+00	2021-03-29 18:23:59.452169+00	697409b4-99ef-4f64-84ee-f0329bb20fab	1
6890c33b-daa6-4e61-aec2-369d908957cc	Таша	\N	Markdown	2021-03-12 17:52:09+00	2021-03-30 18:28:58.657994+00	697409b4-99ef-4f64-84ee-f0329bb20fab	1
e1176ff9-a1f0-489b-9a12-ab9480661712	Таша	\N	Markdown	2021-03-12 14:52:09+00	2021-03-30 20:08:00.496566+00	697409b4-99ef-4f64-84ee-f0329bb20fab	1
a254a112-9a50-4efc-8ca3-8581bc6fb6aa	Таша	\N	Markdown	2021-03-11 21:52:09+00	2021-03-30 21:23:37.508972+00	697409b4-99ef-4f64-84ee-f0329bb20fab	1
69505c86-b1c2-4fc1-94d2-b65162122f3c	Таша	\N	asd\ngg	2021-03-11 21:52:09+00	2021-03-30 21:31:55.787804+00	697409b4-99ef-4f64-84ee-f0329bb20fab	1
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: seasky-developer
--

COPY public."user" (id, username, password, name, email, is_active, role_id, created_at) FROM stdin;
ccf83b8a-8897-48ec-ab26-aae1551a282a	aaaa	$2a$06$o/yLt2DInRIGejZ8kNVYXO2QTd4LXGQQWqRcbKVD8cCTVfSSRy4tW	\N	\N	f	2	2021-03-27 13:21:57.670632+00
697409b4-99ef-4f64-84ee-f0329bb20fab	admin	$2a$06$tD/2NZqxEJi72TXlXBIrduZp/73CQR.yf91aQmkOUL/hce9lRkLCK	\N	\N	t	2	2021-03-27 12:40:30.314822+00
ad8322a7-0d3d-4331-afe4-a1712f73a524	qqqq	$2a$06$xVbJC1ClUk52b9SIMtv1SOT2r2ayMz.1OvZ5tmuuxnR799VH3ikLW	\N	\N	t	2	2021-03-27 13:21:57.670632+00
ce4ec35a-6e0f-42b2-94bf-618f4f8498fc	beaver	$2a$06$HpeO36cluLvA5flk9NDGeeKzJPsdJm4N44tJTJPKbsmAnMQNwQAT2	Бобер Боберыч	beaver@mail.ru	t	1	2021-03-28 17:17:12.480017+00
\.


--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seasky-developer
--

SELECT pg_catalog.setval('public.role_id_seq', 10, true);


--
-- Name: status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seasky-developer
--

SELECT pg_catalog.setval('public.status_id_seq', 4, true);


--
-- Name: detail pk_detail_id; Type: CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.detail
    ADD CONSTRAINT pk_detail_id PRIMARY KEY (id);


--
-- Name: role pk_role_id; Type: CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT pk_role_id PRIMARY KEY (id);


--
-- Name: status pk_status_id; Type: CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT pk_status_id PRIMARY KEY (id);


--
-- Name: task pk_task_id; Type: CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT pk_task_id PRIMARY KEY (id);


--
-- Name: user pk_user_id; Type: CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT pk_user_id PRIMARY KEY (id);


--
-- Name: user uq_user_username; Type: CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT uq_user_username UNIQUE (username);


--
-- Name: detail fk_detail_executor_id_id; Type: FK CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.detail
    ADD CONSTRAINT fk_detail_executor_id_id FOREIGN KEY (executor_id) REFERENCES public."user"(id);


--
-- Name: detail fk_detail_status_id_id; Type: FK CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.detail
    ADD CONSTRAINT fk_detail_status_id_id FOREIGN KEY (status_id) REFERENCES public.status(id);


--
-- Name: detail fk_detail_task_id_id; Type: FK CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.detail
    ADD CONSTRAINT fk_detail_task_id_id FOREIGN KEY (task_id) REFERENCES public.task(id);


--
-- Name: task fk_task_creator_id_id; Type: FK CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT fk_task_creator_id_id FOREIGN KEY (creator_id) REFERENCES public."user"(id);


--
-- Name: task fk_task_status_id_id; Type: FK CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT fk_task_status_id_id FOREIGN KEY (status_id) REFERENCES public.status(id);


--
-- Name: user fk_user_role_id_id; Type: FK CONSTRAINT; Schema: public; Owner: seasky-developer
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT fk_user_role_id_id FOREIGN KEY (role_id) REFERENCES public.role(id);


--
-- PostgreSQL database dump complete
--

